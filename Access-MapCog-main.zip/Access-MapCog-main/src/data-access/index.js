/**
 * @overview
 * Här hanteras api-anrop och olika endpoints för basurl.
 * 
 * @author Viktor Johansson
 * @version 1.0.0
 * @since November, 2023
 */

import createFetch from './fetch';

const BASE_URL =process.env.REACT_APP_API_BASE_URL;

const fetcher = () => {
  if (!BASE_URL){
    console.error('API base URL is not given.');
    return;
  }
  const fetcher = createFetch(BASE_URL);
  return fetcher;
}

const ApiRoutes = {
  getPatientCredentials: async (obj) => await fetcher().fetchJsonData({
    endpoint: '/fetch-mapcog-data',
    method: 'POST',
    body: obj,
  }),
  verifyLogin: async (user) => await fetcher().fetchJsonData({
    endpoint: '/login-mapcog',
    method: 'POST',
    body: user,
    json: false,
  })

};

export default ApiRoutes;