/**
 * @overview
 * Klassen representerar alla knappar med användare i listan
 * 
 * @author Viktor Johansson
 * @version 1.0.0
 * @since November, 2023
 */

import React, { useEffect, useRef, useState } from 'react';
import { FaRegUser } from "react-icons/fa";
import { FaArrowRight } from "react-icons/fa6";

const ListItem = ({ patient, patientList, showTests, index, numOfTests, showUser, setOpenIndex, openIndex, showTestUser}) => {
  const [height, setHeight] = useState(openIndex === index ? 'h-28' : 'h-14');

  const name =
    patient && (patient.firstName === '' || patient.lastName === '')
      ? 'Okänd Användare'
      : `${patient.firstName} ${patient.lastName}`;
  const ref = useRef();
  const toggleContent = () => {
    setHeight('h-28');
    handleItemClick();
  };

  const handleClickOutside = (event) => {
    const node = ref.current;

    if (node && !node.contains(event.target)) {
      setHeight('h-14');
    }
  };

  const item = (
    <button
      onClick={toggleContent}
      className={`w-full ${height} flex items-center justify-between pl-5 pr-5  hover:bg-slate-100 rounded-md cursor-pointer group relative`}
    >
      <h1 className='font-light text-lg text-slate-900'>{name}</h1>
      <h1>{numOfTests} st</h1>
    </button>
  );

  const ButtonComp = ({ comp, onClick, className }) => (
    <button
      onClick={onClick} 
      className={`${className} p-2 hover:bg-slate-300 h-full w-full flex justify-around cursor-pointer`}
    >
      {comp}
    </button>
  );

  const handleItemClick = (index) => {
    setOpenIndex(index);
  };
  
  const itemClicked = (
    <div
      onClick={() => handleItemClick(index)}  
      className={`w-full ${height} bg-white flex flex-col justify-between pt-[0.85rem] pb-[0.85rem] items-start pl-5 pr-5 rounded-md cursor-default group relative`}
    >
      <div className='flex justify-between w-full'>
      <h1 className='font-light text-lg text-slate-900'>{name}</h1>
      <h1>{numOfTests} st</h1>
      </div>
      <div className='w-full flex justify-between bg-slate-200 h-10 min-w-[5.2rem]'>
        <ButtonComp 
          className='w-6 '
          
          onClick={() => {showUser(patientList()[index]); }}
          comp={<span className='flex justify-around items-center'><FaRegUser /></span>}
        />
        <ButtonComp className={`${numOfTests < 1 && 'bg-red-100 hover:bg-red-100 cursor-default'}`}
          onClick={() => {numOfTests > 0 && showTests(patientList()[index]); showTestUser(patientList()[index]);}} 
          comp={<span className={` flex justify-around items-center h-full`}><FaArrowRight /></span>}
        />
      </div>
    </div>
  );

 

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className="mb-2 w-[95%] " ref={ref}>
      {height === 'h-28' ? itemClicked : item}
    </div>
  );
};

export default ListItem;