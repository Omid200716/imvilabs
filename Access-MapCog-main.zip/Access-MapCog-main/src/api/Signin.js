
/**
 * @overview
 * Klassen står för funktioner vid inloggning
 * 
 * @author Viktor Johansson
 * @version 1.0.0
 * @since November, 2023
 */

import ApiRoutes from "../data-access"
import Cookies from 'js-cookie';

const loginVerified = async (userDetails) => {

    try {
        const attemptLogin = await ApiRoutes.verifyLogin({ username: userDetails.username, password: userDetails.password });
        if (attemptLogin.status === 200) {
            return true;
        }
    } catch (err) {
        console.error('Error during login verification:', err);
    }
    return false;
}

const signout = () => {
    if (Cookies.get('session_user') !== null) {
        Cookies.remove('session_user');
        Cookies.remove('origin');
        return true;
    }
    return false;
}

const signin = async (userDetails) => {
    try {
        const verify = await loginVerified(userDetails);
        if (verify) {

            const credentials = await ApiRoutes.getPatientCredentials({legpers: userDetails.username});

            return credentials;

        }
    } catch (error) {
        console.error(error);
    }

    return null;
}

export { signin, signout };